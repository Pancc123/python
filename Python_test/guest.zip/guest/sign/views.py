from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from sign.models import Event, Guest
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render_to_response
from django.template import RequestContext



# Create your views here.


def index(request):
    #return HttpResponse("Hello Django")
    return render(request, 'index.html')


def login_action(request):
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
       # if username == 'admin' and password == 'admin123':
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user) #登录
            request.session['user'] = username
            #response HttpResponse('login success!')
            response = HttpResponseRedirect('/event_manage/')  #登录成功后对路径重定向
            #response.set_cookie('user', username, 3600)   #添加浏览器Cookie
            #request.session['user'] = username   #将session信息记录到浏览器
            return response
        else:
            return render(request, 'index.html', {'error': 'username or password error !'})
#发布管理


@login_required
def event_manage(request):

    #username = request.COOKIES.get('user', '')    #读取浏览器cookie
    event_list= Event.objects.all()
    username = request.session.get('user', '')   #读取浏览器session
    return render(request, "event_manage.html", {"user": username, "events": event_list})


def search_name(request):
    username = request.session.get('username', '')
    search_name_q = request.GET.get("name", "")
   # search_name_bytes = search_name_q.encode("utf-8")
    event_list = Event.objects.filter(name__contains=search_name_q)
    #event_list = Event.objects.get(name="小米5发布会")
    return render(request, "event_manage.html", {"user": username, "events": event_list})


def logout(request):
    auth.logout(request)    #退出登录
    response = HttpResponseRedirect('/index/')
    return response



    '''username = request.session.get('user', '')
    search_name = request.GET.get("name", "")
    search_name_bytes = search_name.encode(encoding="utf-8")
    event_list = Event.objects.filter(name__contains=search_name_bytes)
    return render(request, "event_manage.html", {"user": username, "events": event_list})'''


def guest_manage(request):
    username = request.session.get("user", "")
    guest_list = Guest.objects.all()
    paginator = Paginator(guest_list, 2)
    page = request.GET.get('page')
    try:
        contacts = paginator.page(page)
    except PageNotAnInteger:     #如果page不是整数，取第一页数据
        contacts = paginator.page(1)
    except EmptyPage:#page 不在范围，取最后一页数据
        contacts = paginator.page(paginator.num_pages)
    return render(request, "guest_manage.html", {"user": username, "guests": contacts})


def search_phone(request):
    username = request.session.get("user", "")
    search_phone_q = request.GET.get("phone", "")
    guest_list = Guest.objects.filter(phone__contains=search_phone_q)
    return render(request, "guest_manage.html", {"user": username, "guests": guest_list})

@login_required
def sign_index(request,event_id ):
    event = get_object_or_404(Event, id=event_id)
    return render(request, 'sign_index.html', {'event': event})


def sign_index2(request, event_id):
    event_name = get_object_or_404(Event, id=event_id)
    return render(request, 'sign_index2.html', {'eventId': event_id, 'eventName': event_name})

@login_required
def sign_index_action(request, event_id):

    event = get_object_or_404(Event, id=event_id)
    guest_list = Guest.objects.filter(event_id=event_id)
    sign_list = Guest.objects.filter(sign="1", event_id=event_id)
    guest_data = str(len(guest_list))
    sign_data = str(len(sign_list))

    phone = request.POST.get('phone','')

    result = Guest.objects.filter(phone = phone)
    if not result:
        return render(request, 'sign_index.html', {'event': event,'hint': 'phone error.','guest':guest_data,'sign':sign_data})

    result = Guest.objects.filter(phone = phone,event_id = event_id)
    if not result:
        return render(request, 'sign_index.html', {'event': event,'hint': 'event id or phone error.','guest':guest_data,'sign':sign_data})

    result = Guest.objects.get(event_id = event_id,phone = phone)

    if result.sign:
        return render(request, 'sign_index.html', {'event': event,'hint': "user has sign in.",'guest':guest_data,'sign':sign_data})
    else:
        Guest.objects.filter(event_id = event_id,phone = phone).update(sign = '1')
        return render(request, 'sign_index.html', {'event': event,'hint':'sign in success!',
            'user': result,
            'guest':guest_data,
            'sign':str(int(sign_data)+1)
            })

