from pymysql import cursors, connect

conn = connect(host='localhost', user='root', password='pan123456',db='guest', charset='utf8mb4',
               cursorclass=cursors.DictCursor)
try:
    with conn.cursor() as cursor:
        #创建嘉宾数据
         sql = 'insert into sign_guest (realname, phone, email, sign, ' \
               'event_id, create_time) values ("Tom", 15067196993, "tom@mail.com", 0,1 ,NOW());'
         cursor.execute(sql)
        #提交数据
    conn.commit()

    with conn.cursor() as cursor:
        #查询添加数据
        sql= 'select realname,phone,email,sign from sign_guest where phone=%s'
        cursor.execute(sql, ('15067196993',))
        result = cursor.fetchone()
        print(reslut)
finally:
    conn.close()





