def make_sandwich(*toppings):
	print('Making a sandwich with the following toppings:')
	for topping in toppings:
		print(topping)
