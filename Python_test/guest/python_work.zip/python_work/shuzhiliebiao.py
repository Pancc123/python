numbers=list(range(1,1000001))
print(min(numbers))
print(max(numbers))
print(sum(numbers)) 
qishu=list(range(1,21,2))
for rt in qishu:
	print(rt)
chu=list(range(3,31,3))
for mn in chu:
    print(mn)
result=[]
for lf in range(1,11):
     lf=lf**3
     result.append(lf)
print(result)
new=[aa**3  for aa in range(1,11)]
print(new) 
	
