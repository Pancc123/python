import Car
Car.my_new_car.oldmeter_reading=23
Car.my_new_car.read_odometer()
