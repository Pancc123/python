alien=['green','red','yellow']
if 'green' in alien:
	print('Player win 5 point')
elif 'yellow' in alien:
	print('Player win 10 point')
else:
	print('Player win 15 point')
    
    


