# panchengcheng --20170824
famous_name='\tAlbert\t\n\tEinstein\t'
print(famous_name)
print(famous_name.rstrip())
print(famous_name.lstrip())
print(famous_name.strip())
print(5+3)
print(2*4)
print(16/2)
print(9-1)
digital=str(6)
print(digital)
