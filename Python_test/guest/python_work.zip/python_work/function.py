def make_shirt(size_number,messages):
   print('the size of shirt:'+size_number)
   print('the message of shirt:'+messages)
make_shirt('15','come on')
def descirbe_pet(animal_type,pet_name):
	print("\nI have a " + animal_type +'.')
	print('My ' +animal_type+"'s name is " + pet_name.title())
descirbe_pet('cat','bobo')


