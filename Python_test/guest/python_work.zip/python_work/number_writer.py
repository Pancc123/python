import json
numbers=[2,3,4,5,6,7,9]
filename='number.json'
with open(filename,'w') as file_object:
	json.dump(numbers,file_object)
