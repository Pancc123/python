new='abddf'
old='dgsgsag'
if(new==old):
	print('True')
else:
	print('False')



color='Red'
print(color=='red')
color=color.lower()
print(color=='red')
print(color)

fruit=['apple','orange','watermelon','banana']
best_fruit='apple'
if best_fruit in fruit:
	print('My favorite fruit is '+best_fruit+'.')
	
age=18
if age>=18:
	print('you are old enough to vote!')
	print('Have you registered to vote yet?')
else:
	print('Sorry,you are too young to vote.')
	print('Please register to as soon as you turn 18!')

age=15
if(age<=4):
	print('your admission cost is $0.')
elif (age<18):
	print('your admission cost is $5.')
else:
	print('your admission cost is $10.')

	
