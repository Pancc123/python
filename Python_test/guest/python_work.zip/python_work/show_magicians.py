def show_magicians(magicians_name):
	for name in magicians_name:
		print('magicians: '+ name.title())
