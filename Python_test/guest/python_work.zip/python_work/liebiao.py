the_beauty=['linyune','liuyifei','songhuiqiao']
print('hai,'+the_beauty[0]+'! Cat i have dinner with you?')
print('Hi, '+the_beauty[1]+' Cat i have a dinner with you?')
print('Hi, '+the_beauty[2]+' Cat i have a dinner with you?')
print(' the name who i want to invert is'+the_beauty[0])
the_beauty[2]='lizi'
print(the_beauty)
print('I find a big desk we cat have a dinner')
the_beauty.insert(0,'lijiaxin')
the_beauty.insert(2,'baby')
the_beauty.append('qiushuzhen')
print(the_beauty)
print('I hope all of them can come')
print(' there is only a desk. So i only have dinner with two pepole')
fail=the_beauty.pop()
print('I am sorry that '+fail+' can not have dinner with me')
second=the_beauty.pop()
print('i am sorry that '+second+' can not have a dinner with me')
third=the_beauty.pop()
print(' I am sorry that '+third+' can not have a dinner with me')
print('Hi, '+the_beauty[0]+' can you have a dinner with me.')
print('Hi, '+the_beauty[1]+' can you have a dinner with me.')
del the_beauty[0]
del the_beauty[0]
del the_beauty[0]
print(the_beauty)
