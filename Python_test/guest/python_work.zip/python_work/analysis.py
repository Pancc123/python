title='Alice in Wonderland'
new_title=title.split()
print(new_title)
