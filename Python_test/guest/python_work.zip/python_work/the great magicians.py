from show_magicians import *
from make_great import *
magicians_name=['liuqian','cheng','chao']
new_name=[]
make_great(magicians_name,new_name)
show_magicians(new_name)
