# -*- coding:utf-8 -*-
import csv
filename='D:/test.csv'
f = open(filename,'r',encoding='utf-8')
reader=csv.reader(f).decode('utf-8')
	#words=next(reader)
for row in reader:
	for i in row:
		print(i)

#list=['1','2','3','4']
#with open('file_write.csv','w') as f:
#	csv_writer=csv.writer(f)
#	csv_writer.writerow(list)
