the_buffet=('miaobao','chicken','fruit','drinks','wine')
for food in the_buffet:
	print(food)
the_buffet=('meat','eggs','fruit','drinks','wine')
for tea in the_buffet:
    print(tea)
