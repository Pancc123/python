number=list(range(1,10))
for i in number:
	if i==1:
		print('1st')
	elif i==2:
		print('2th')
	elif i==3:
		print('3th')
	elif i==4:
		print('4th')
	elif i==5:
		print('5th')
	elif i==6:
		print('6th')
	elif i==7:
		print('7th')
	elif i==8:
		print('8th')
	else:
		print('9th')
	
	
	
	
