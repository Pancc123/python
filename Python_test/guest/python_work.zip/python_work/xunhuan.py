current_users=['andy','wang','chen','lin','xia']
new_users=['andy','wang','chen','lin','xia','jiang']
for users in new_users:
	if users.lower() in current_users:
		print('Please enter other user_name')
	else:
		print('this user_name is not used')
