def get_formatted_name(first_name,last_name):
	full_name=first_name +' '+ last_name
	return full_name.title()
	

#man=get_formatted_name('janis','joplin')
#print(man)
