first_name='I '
last_name='love you'
full_name=first_name+last_name
print(full_name)
print("go\n")
print('he say '+full_name.title()+'!')
print('\t me\n')
full_name='wuguang'
print(full_name)
fruit='watermelon '
print('watermelon '+'i like')
print(fruit.rstrip()+'i like')



