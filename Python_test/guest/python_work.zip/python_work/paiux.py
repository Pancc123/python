cars=['bmw','audi','toyta','subaru']
print(sorted(cars))
print(cars)
girls=['lin yun e','li jia xin','zhu yin']
leng=len(girls)
print(leng)
