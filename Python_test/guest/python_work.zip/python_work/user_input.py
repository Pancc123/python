message=input('Tell me someting,and I will repeat it back to you:')
print(message)
