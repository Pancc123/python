file_name='text_files//cat.txt'
with open(file_name) as object:
	contents=object.read()
	print(contents)
