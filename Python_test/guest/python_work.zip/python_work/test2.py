import sandwich as mo
mo.make_sandwich('vegetables','banana')
