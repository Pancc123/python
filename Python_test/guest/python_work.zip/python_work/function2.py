def make_shirt(size='big',message='I love python'):
    print('the size of shirt: '+size)
    print('the message of shirt: '+message)
make_shirt()
make_shirt('middle')
make_shirt(message='comeon baby')

def get_formatted_name(first_name,last_name):
	full_name=first_name+''+last_name
	return(full_name.title())
while True:
	print("if you want to stop,please enter 'q'")
	f_name=input('please input first_name: ')
	if f_name =='q':
		break
	l_name=input('please input last_name: ')
	if l_name=='q':
		break
	formatted_name=get_formatted_name(f_name,l_name)
	print('\nHello,'+formatted_name+'!') 

def city_country(city_name,country):
	message=city_name+','+country
	return(message.title())
city_message=city_country('shanghai','china')
print(city_message)

def make_album(name,music,number=''):
	singer_message={'singer_name':name,'singer_music':music}
	if number:
		singer_message['number']=number
	return(singer_message)
while True:
	print("if you want to stop,enter 'q'!")
	m_name=input("please enter singer's name:")
	if m_name =='q':
		break
	s_music=input("please enter the name of music:")
	if s_music=='q':
		break
	m_number=input("please enter the number of musc")
	if m_number=='q':
		break
	all_message=make_album(m_name,s_music,m_number)
	print(all_message)
		
